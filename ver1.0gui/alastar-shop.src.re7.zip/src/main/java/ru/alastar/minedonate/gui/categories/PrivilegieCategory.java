package ru.alastar.minedonate.gui.categories;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.Tessellator;

import org.lwjgl.opengl.GL11;
import ru.alastar.minedonate.MineDonate;
import ru.alastar.minedonate.gui.BuyButton;
import ru.alastar.minedonate.gui.ShopCategory;
import ru.alastar.minedonate.gui.ShopGUI;
import ru.alastar.minedonate.merch.IMerch;
import ru.alastar.minedonate.merch.info.PrivilegieInfo;
import ru.alastar.minedonate.proxies.ClientProxy;
import ru.log_inil.mc.minedonate.gui.DrawType;
import ru.log_inil.mc.minedonate.gui.painters.PrivilegieGridItemPainter;

import java.util.ArrayList;

/**
 * Created by Alastar on 20.07.2017.
 */
public class PrivilegieCategory implements ShopCategory {

    @Override
    public String getName() {
        return "Privelegies";
    }

    PrivilegieGridItemPainter pip ; // #LOG
    
    public PrivilegieCategory ( ) {
    	
    	pip = new PrivilegieGridItemPainter ( this ) ;
    			 
    }
    
    IMerch info ;
    ScaledResolution resolution ;
    
    @Override
    public void draw(ShopGUI relative, int page, int mouseX, int mouseY, float partialTicks, DrawType dt) {
		ScaledResolution resolution = new ScaledResolution( relative.mc, relative.mc.displayWidth, relative.mc.displayHeight);
		
    	if ( dt == DrawType.PRE){
    		
      	   // relative.drawRect(30, (int) (resolution.getScaledHeight() * 0.1) + 15+24, resolution.getScaledWidth()-30,  (int) ( (resolution.getScaledHeight()) - (resolution.getScaledHeight() * 0.1) ) - 5, 1258291200);
      	   relative.drawGradientRectAccess(30, (int) (resolution.getScaledHeight() * 0.1) + 19+20, resolution.getScaledWidth()-30,  (int) ( (resolution.getScaledHeight()) - (resolution.getScaledHeight() * 0.1) ) - 5,  -1072689136, -804253680);

	        if (page < MineDonate.m_Categories[1].getMerch().length) {
	        	
	        	info = MineDonate.m_Categories[1].getMerch()[page];
	        	
	        	pip.draw(relative, resolution, 0, mouseX, mouseY, partialTicks, info, 0, 0);
	        	
	        } 
	        
    	} else if ( dt == DrawType.POST ) {
        	
	  	   // relative.drawRect(30, (int) (resolution.getScaledHeight() * 0.1) + 15+24, resolution.getScaledWidth()-30,  (int) ( (resolution.getScaledHeight()) - (resolution.getScaledHeight() * 0.1) ) - 5, 1258291200);
	  	   

	        
	        GL11.glEnable(GL11.GL_BLEND);
	        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
	        GL11.glDisable(GL11.GL_ALPHA_TEST);
	        GL11.glShadeModel(GL11.GL_SMOOTH);
	        GL11.glDisable(GL11.GL_TEXTURE_2D);
	        
	        //
	        
	        Tessellator var18 = Tessellator.instance;
	        byte var20 = 12;
	        
	        // 30, (int) (resolution.getScaledHeight() * 0.1) + 15+24, resolution.getScaledWidth()-30,  (int) ( (resolution.getScaledHeight()) - (resolution.getScaledHeight() * 0.1) ) - 5,  -1072689136, -804253680);
   
	        var18.startDrawingQuads();
	        
	        var18.setColorRGBA_I(0, 0);
	        
	        var18.addVertexWithUV((double)30, (double)((int) (resolution.getScaledHeight() * 0.1) + 19+20+ var20), 0.0D, 0.0D, 1.0D);
	        var18.addVertexWithUV((double)(int) resolution.getScaledWidth()-30, (double)( (resolution.getScaledHeight() * 0.1) + 19+20 + var20), 0.0D, 1.0D, 1.0D);
	        
	        var18.setColorRGBA_I(0, 255);
	        
	        var18.addVertexWithUV((double)resolution.getScaledWidth()-30, (double)(int) (resolution.getScaledHeight() * 0.1) + 19+20, 0.0D, 1.0D, 0.0D);
	        var18.addVertexWithUV((double)30, (double)(int) (resolution.getScaledHeight() * 0.1) + 19+20, 0.0D, 0.0D, 0.0D);
	        
	        var18.draw();

	        
	        var18.startDrawingQuads();
	        
	        var18.setColorRGBA_I(0, 255);
	        
	        var18.addVertexWithUV((double)30, (double) ( (resolution.getScaledHeight()) - (resolution.getScaledHeight() * 0.1) ) - 6, 0.0D, 0.0D, 1.0D);
	        var18.addVertexWithUV((double)resolution.getScaledWidth()-30, (double) ( (resolution.getScaledHeight()) - (resolution.getScaledHeight() * 0.1) ) - 6, 0.0D, 1.0D, 1.0D);
	        
	        var18.setColorRGBA_I(0, 0);
	        
	        var18.addVertexWithUV((double)resolution.getScaledWidth()-30, (double)( ( (resolution.getScaledHeight()) - (resolution.getScaledHeight() * 0.1) ) - 6 - var20), 0.0D, 1.0D, 0.0D);
	        var18.addVertexWithUV((double)30, (double)( ( (resolution.getScaledHeight()) - (resolution.getScaledHeight() * 0.1) ) - 6 - var20), 0.0D, 0.0D, 0.0D);
	        
	        var18.draw();
	        
	        //
	        
	        GL11.glEnable(GL11.GL_TEXTURE_2D);
	        GL11.glShadeModel(GL11.GL_FLAT);
	        GL11.glEnable(GL11.GL_ALPHA_TEST);
	        GL11.glDisable(GL11.GL_BLEND);
	        
        }
        
    }
    
    public BuyButton bb ;
    
    @Override
    public void updateButtons(ShopGUI relative, int page) {
        System.out.println("Page: " + page);
        if (page < MineDonate.m_Categories[1].getMerch().length) {
            PrivilegieInfo info = (PrivilegieInfo) MineDonate.m_Categories[1].getMerch()[page];
            ScaledResolution resolution = new ScaledResolution(relative.mc, relative.mc.displayWidth, relative.mc.displayHeight);

            int y_offset = (int) (resolution.getScaledHeight() * 0.30);
            
            relative.addBtn( bb = new BuyButton(info.merch_id, ShopGUI.getNextButtonId(), (bb!=null?bb.xPosition: resolution . getScaledWidth ( ) / 2 - MineDonate.cfgUI.cats.privelegies.itemBuyButton.width / 2), y_offset +  93, MineDonate.cfgUI.cats.privelegies.itemBuyButton.width, MineDonate.cfgUI.cats.privelegies.itemBuyButton.height, MineDonate.cfgUI.cats.privelegies.itemBuyButton.text));//#LOG

        }
    }

    @Override
    public boolean getEnabled() {
        return MineDonate.cfg.sellPrivelegies;
    }

    @Override
    public int getSourceCount() {
        return MineDonate.m_Categories[1].getMerch().length;
    }

    @Override
    public int elements_per_page() {
        return 1;
    }

    @Override
    public void actionPerformed(GuiButton button) {
        
    }
    
    // #LOG
    
	@Override
	public int getButtonWidth ( ) {
		
		return MineDonate.cfgUI.cats.privelegies.categoryButtonWidth;
		
	}
	
	@Override 
	public String getButtonText ( ) {
		
		return MineDonate.cfgUI.cats.privelegies.categoryButtonText ;
		
	}
	
	@Override
	public int getRowCount() {
		return 0;
	}

	@Override
	public void setRowCount(int i) {
	}

	@Override
	public int getColCount() {
		
		return 0;
		
	}

	@Override
	public void setColCount(int i) {
	}

	@Override
	public int getItemWidth() {
		
		return 0;

	}

	@Override
	public int getItemHeight() {
		
		return 0;
		
	}

	@Override
	public void init(ShopGUI shopGUI) {		
	}

	@Override
	public void initGui() {		
	}
	
}

package ru.alastar.minedonate.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderItem;
import ru.alastar.minedonate.MineDonate;
import ru.alastar.minedonate.gui.categories.EntitiesCategory;
import ru.alastar.minedonate.gui.categories.ItemNBlockCategory;
import ru.alastar.minedonate.gui.categories.PrivilegieCategory;
import ru.alastar.minedonate.gui.categories.RegionsCategory;
import ru.alastar.minedonate.network.MineDonateNetwork;
import ru.alastar.minedonate.network.packets.NeedUpdatePacket;
import ru.alastar.minedonate.proxies.ClientProxy;
import ru.log_inil.mc.minedonate.gui.DrawType;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.GL11;

/**
 * Created by Alastar on 18.07.2017.
 */
public class ShopGUI extends GuiScreen {
	
    public static ShopGUI instance;
    public boolean needNetUpdate = true ;
    public boolean loading = false ;

    private boolean can_process = true;
    private static int m_last_id = 3;
    public static int m_Page = 0;
    // private ShopCategory[] m_Categories = new ShopCategory[]{new ItemNBlockCategory(), new PrivilegieCategory(), new RegionsCategory(), new EntitiesCategory()};
    private int m_Selected_Category = 0;   // 0 - blocks & items, 1 - privilegies, 2 - wg regions, 3 - entities
    private ShopCategory[] cats = new ShopCategory[]{new ItemNBlockCategory(), new PrivilegieCategory(), new RegionsCategory(), new EntitiesCategory()};
    
    public ShopGUI ( ) {

    	for ( ShopCategory sc: cats ) {
    		
    		sc . init ( this ) ;
    		
    	}
    	
    }

    public static int getNextButtonId ( ) {
        
    	return m_last_id ++ ;
        
    }

    public ShopCategory [ ] getCurrentShopCategories ( ) { // #LOG
    	
    	return cats ;
    	
    }
    
    public ShopCategory getCurrentCategory ( ) {
    	
    	return cats [ m_Selected_Category ] ;
    	
    }
    
    //#LOG
    @Override
    protected void keyTyped ( char p_73869_1_, int p_73869_2_ ) {

    	// 32 205 -> d
    	// 30 203 <- a
    	if ( ( 30 == p_73869_2_  || 203 == p_73869_2_ ) && pb . enabled ) {

    		actionPerformed ( pb ) ;
    		
    	} else if ( ( 32 == p_73869_2_  || 205 == p_73869_2_ ) && nb . enabled ) {

    		actionPerformed ( nb ) ;

    	} else if ( ClientProxy . openHUD . getKeyCode ( ) == p_73869_2_ ) {
    		
    		Minecraft . getMinecraft ( ) . displayGuiScreen( null ) ;
    		
    	} else {
    		
    		super . keyTyped ( p_73869_1_, p_73869_2_ ) ;
    		
    	}
    	
    }
    
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
    //    this.drawDefaultBackground();
    	
    	
        ScaledResolution resolution = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);

        this.drawRect(0, 0, resolution.getScaledWidth(), resolution.getScaledHeight(), 1258291200);
     
        if ( ! loading ) {
        	
	        String vault = String.format( MineDonate.cfgUI.moneyLinePrefix+ "%d" + MineDonate.cfgUI.moneyLineSuffix, MineDonate.m_Client_Money) ;
	        this.drawCenteredString(this.fontRendererObj, vault, resolution.getScaledWidth() - this.fontRendererObj.getStringWidth(vault)-3, (int) (resolution.getScaledHeight() * 0.1)+20+5, 16777215);
	       
	        getCurrentCategory ( ) . draw ( this, m_Page, mouseX, mouseY, partialTicks, DrawType . PRE ) ;   
	
	        super.drawScreen(mouseX, mouseY, partialTicks);
	          
	        getCurrentCategory ( ) . draw ( this, m_Page, mouseX, mouseY, partialTicks, DrawType . POST ) ;   
	
	        can_process = true;
	        
	    } else {
	    	
	    	this.drawRect((resolution.getScaledWidth()/2)-10-this.fontRendererObj.getStringWidth(MineDonate.cfgUI.loadingText)/2, (resolution.getScaledHeight()/2)-5, (resolution.getScaledWidth()/2)+10+this.fontRendererObj.getStringWidth(MineDonate.cfgUI.loadingText)/2, (resolution.getScaledHeight()/2) + 15, 1258291200);
		  	   
	    	this.drawCenteredString( this.fontRendererObj, MineDonate.cfgUI.loadingText, resolution.getScaledWidth()/2, resolution.getScaledHeight()/2, 16777215);
	    	
	    }
        
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    protected void actionPerformed(GuiButton button) {
    	
        if(can_process) {
        	
            can_process = false;
            
            if (button.id == 0) {
            	
                button.enabled = false;
                this.mc.thePlayer.closeScreen();
                
            } else if (button instanceof PreviousButton) {
            	
                button.enabled = false;
                m_Page = m_Page - 1;
                updateGrid ( ) ;
                updateBtns();
                
            } else if (button instanceof NextButton) {
            	
                button.enabled = false;
                m_Page = m_Page + 1;
                System.out.println("new page is: " + m_Page);
                updateGrid ( ) ;
                updateBtns();
                
            } else if (button instanceof BuyButton ) {
                
            	((BuyButton) button).buy(m_Selected_Category);
            	
            } else if (button instanceof CategoryButton) {
            	 	
                m_Page = 0;
                m_Selected_Category = ((CategoryButton) button).getCategory();
                
                resolution = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight); // #LOG
                
                updateGrid ( ) ;
                updateBtns ( ) ;
                
            }
            
            getCurrentCategory ( ) . actionPerformed ( button ) ;
            
        }
    }

    public void drawHoveringText(ArrayList list, int mouseX, int mouseY, FontRenderer fontRenderer) {
        super.drawHoveringText(list, mouseX, mouseY, fontRenderer);
    }

    @Override
    public void initGui() {
    	
        instance = this;
        resolution = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight); // #LOG
        m_Page = 0 ;
        updateGrid ( ) ; // #LOG
        updateBtns ( ) ;
        getCurrentCategory ( ) . initGui ( ) ;
        
		if ( needNetUpdate && ! loading ) {
    		
            MineDonateNetwork . INSTANCE . sendToServer ( new NeedUpdatePacket ( 0 ) ) ;
            loading = true ;
            
        }

		
    }

    int widthCatsBlock = 0 ;
    private void addCategories() {
        int offset = 0;
        ScaledResolution resolution = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
        ScaledResolution resolution0 ;

        int posX = 0 ;
        widthCatsBlock = 0 ;
        for ( ShopCategory sc : getCurrentShopCategories ( ) ) {//#LOG
        	if ( sc.getEnabled() ) { 
        		resolution0 = new ScaledResolution(this.mc, sc.getButtonWidth()+5, 0 ); //TODO rewrite
        		widthCatsBlock += resolution0.getScaledWidth() ; 		
        	}
        }

        posX = 30 ; //( resolution . getScaledWidth ( ) / 2 ) - ( widthCatsBlock / 2 ) ;
        
        for (int i = 0; i < getCurrentShopCategories ( ).length; ++i) {
        	
        	if ( getCurrentShopCategories ( ) [ i ] . getEnabled ( ) ) { //#LOG
        		
	            CategoryButton btn = new CategoryButton ( i, getNextButtonId(), posX, (int) (resolution.getScaledHeight() * 0.1) + 19, getCurrentShopCategories ( ) [i].getButtonText() ) ;
	          
	            btn.width = getCurrentShopCategories ( ) [ i ] .getButtonWidth(); // 75
	            this . addBtn ( btn ) ;
	      
	            posX += btn.width ;
	            
	            if ( i == m_Selected_Category ) { // #LOG
	            	
	            	btn . enabled = false ;
	            	
	            } else {
	            	
	            	btn . enabled = true ;
	            	
	            }
	            
        	}
        	
        }
    }


    public void addBtn(GuiButton b) {
        this.buttonList.add(b);
    }

    PreviousButton pb ;
    NextButton nb ;
    public ScaledResolution resolution ;
    GuiButton exitButton ;
    
    public void updateBtns() {
    	
        //System.out.println("clear buttons");
        buttonList.clear();
        addCategories();
        //System.out.println("added category buttons");

        getCurrentCategory ( ) . updateButtons ( this, m_Page ) ;
        //System.out.println("updated category buttons");
        
        buttonList.add(exitButton = new GuiButton(0, (int) (resolution.getScaledWidth() * 0.5) - MineDonate.cfgUI.exitButton.width/2, (int) ( (resolution.getScaledHeight()) - (resolution.getScaledHeight() * 0.1) ), MineDonate.cfgUI.exitButton.width, MineDonate.cfgUI.exitButton.height, MineDonate.cfgUI.exitButton.text));//Close button "X"

        buttonList.add(pb = new PreviousButton(ShopGUI.getNextButtonId(), exitButton.xPosition - 4 - 20, exitButton.yPosition, 20, 20, "<"));
        buttonList.add(nb = new NextButton(ShopGUI.getNextButtonId(), exitButton.xPosition+exitButton.width+4, exitButton.yPosition, 20, 20, ">"));

        if ( getCurrentCategory ( ).getSourceCount() > getCurrentCategory ( ) . elements_per_page()) {

            pb . enabled = (m_Page > 0) ;

            nb . enabled = getCurrentCategory ( ).elements_per_page() > 0 && m_Page < (int) Math.ceil(getCurrentCategory ( ).getSourceCount() / (getCurrentCategory ( ).elements_per_page()));

        } else {
        	
        	pb . enabled = nb . enabled = false ;
        	
        }
        
    }

    int tmpH ;
    public void updateGrid ( ) { // #LOG
			
		int tmpW ;

		if ( getCurrentCategory ( ) . getItemWidth ( ) > 0 ) {
    		
    		tmpH = resolution . getScaledHeight ( ) - 50 - 25 ;
    		
    		tmpW = resolution . getScaledWidth ( ) - 50 - 50 ;
    		
    		getCurrentCategory ( ) . setColCount ( tmpW / getCurrentCategory ( ) . getItemWidth ( ) ) ;
    		
    		getCurrentCategory ( ) . setRowCount ( tmpH / getCurrentCategory ( ) . getItemHeight ( ) ) ;
    		    		
    	}
    	
    }
    
    public FontRenderer getFontRenderer() {
        return this.fontRendererObj;
    }

    public RenderItem getItemRender() {
        return this.itemRender;
    }

    public List getLabels() {
        return this.labelList;
    }
    
    public void drawGradientRectAccess(int par1, int par2, int par3, int par4, int par5, int par6) {
    	drawGradientRect(par1, par2, par3, par4, par5, par6) ;
    }

}
package ru.alastar.minedonate.proxies;

import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.relauncher.Side;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

import ru.alastar.minedonate.MineDonate;
import ru.alastar.minedonate.events.KeyInputEvent;
import ru.alastar.minedonate.events.PlayerConnectedEvent;
import ru.alastar.minedonate.network.MineDonateNetwork;
import ru.alastar.minedonate.network.handlers.NeedUpdateClientPacketHandler;
import ru.alastar.minedonate.network.handlers.NeedUpdateServerPacketHandler;
import ru.alastar.minedonate.network.packets.NeedUpdatePacket;
import ru.log_inil.mc.minedonate.localData.DataOfConfig;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;

/**
 * Created by Alastar on 01.04.2017.
 */
public class ClientProxy extends CommonProxy{

    public static KeyBinding openHUD = new KeyBinding("minedonate.open", Keyboard.KEY_EQUALS, "key.minedonate.main");

    public static DynamicTexture[] m_Privelegies_Icons = new  DynamicTexture[0];
    @Override
    public void preInit(FMLPreInitializationEvent event) {
        super.preInit(event);
        
        MineDonateNetwork.INSTANCE.registerMessage(NeedUpdateClientPacketHandler.class, NeedUpdatePacket.class, 7, Side.CLIENT);
        FMLCommonHandler.instance().bus().register(new PlayerConnectedEvent());
        FMLCommonHandler.instance().bus().register(new KeyInputEvent());
        MineDonate . initClientConfig ( ) ;
        ClientRegistry.registerKeyBinding(openHUD);
        
    }
    static ResourceLocation res = new ResourceLocation(MineDonate.MODID.toLowerCase(), "cash");
    public static void playCash(){

        int x =    (int)Minecraft.getMinecraft().thePlayer.posX;
        int y =    (int)Minecraft.getMinecraft().thePlayer.posY;
        int z =    (int)Minecraft.getMinecraft().thePlayer.posZ;

        Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.func_147675_a(res, x, y, z));
    }

    public static void loadIcon(String url, int id){
        BufferedImage image = null;
        System.out.println("Icon url: " + url);

        try {
            image = ImageIO.read(new URL(url));
            if(image != null) {
                DynamicTexture dyn_tex = new DynamicTexture(image);
                if(id >= m_Privelegies_Icons.length)
                    m_Privelegies_Icons = Arrays.copyOf(m_Privelegies_Icons, id + 1);
                m_Privelegies_Icons[id] = dyn_tex;
            }
            else{
                System.out.println("Null image!!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static DynamicTexture getImage(int id ){
        return m_Privelegies_Icons[id];
    }

}
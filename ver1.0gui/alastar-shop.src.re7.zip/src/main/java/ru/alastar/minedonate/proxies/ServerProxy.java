package ru.alastar.minedonate.proxies;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.relauncher.Side;
import ru.alastar.minedonate.MineDonate;
import ru.alastar.minedonate.events.PlayerConnectedEvent;
import ru.alastar.minedonate.network.MineDonateNetwork;
import ru.alastar.minedonate.network.handlers.NeedUpdateServerPacketHandler;
import ru.alastar.minedonate.network.packets.NeedUpdatePacket;

/**
 * Created by Alastar on 01.04.2017.
 */
public class ServerProxy extends CommonProxy {
	
    @Override
    public void preInit(FMLPreInitializationEvent event) {
    	
        super.preInit(event);
        MineDonateNetwork.INSTANCE.registerMessage(NeedUpdateServerPacketHandler.class, NeedUpdatePacket.class, 7, Side.SERVER);

        MineDonate.initLog();     
        MineDonate . initServerConfig ( ) ;
        MineDonate.InitDataBase();
        
       // FMLCommonHandler.instance().bus().register(new PlayerConnectedEvent());
        
    }
    
}

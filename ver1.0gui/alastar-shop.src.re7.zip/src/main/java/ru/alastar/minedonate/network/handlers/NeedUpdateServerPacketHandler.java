package ru.alastar.minedonate.network.handlers;

import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import net.minecraft.entity.player.EntityPlayerMP;
import ru.alastar.minedonate.MineDonate;
import ru.alastar.minedonate.gui.ShopGUI;
import ru.alastar.minedonate.network.MineDonateNetwork;
import ru.alastar.minedonate.network.packets.AccountInfoPacket;
import ru.alastar.minedonate.network.packets.AddMerchPacket;
import ru.alastar.minedonate.network.packets.MerchInfoPacket;
import ru.alastar.minedonate.network.packets.NeedUpdatePacket;
import ru.alastar.minedonate.network.packets.SupportedFeaturesPacket;

public class NeedUpdateServerPacketHandler implements IMessageHandler<NeedUpdatePacket, IMessage> {
    
	public NeedUpdateServerPacketHandler(){

    }
    
    @Override 
    public IMessage onMessage(NeedUpdatePacket message, MessageContext ctx) {
    	
    	if ( message . r == 0 ) {
    		
    		if (MineDonate.m_Enabled) {
                EntityPlayerMP serverPlayer = ctx.getServerHandler().playerEntity;
                if (!MineDonate.ExistsAccount(serverPlayer)) {
                    MineDonate.RegisterPlayer(serverPlayer);
                }
                SupportedFeaturesPacket features_packet = new SupportedFeaturesPacket(MineDonate.cfg.sellItems, MineDonate.cfg.sellPrivelegies, MineDonate.cfg.sellRegions, MineDonate.cfg.sellEntities);
                MineDonateNetwork.INSTANCE.sendTo(features_packet, serverPlayer);
                AccountInfoPacket info_packet = new AccountInfoPacket(MineDonate.getInstance().getMoneyFor(serverPlayer.getDisplayName()));
                MineDonateNetwork.INSTANCE.sendTo(info_packet, serverPlayer);
                
                for (int i = 0; i < MineDonate.m_Categories.length; ++i) {
                    for (int j = 0; j < MineDonate.m_Categories[i].getMerch().length; ++j) {
                        AddMerchPacket packet = new AddMerchPacket(MineDonate.m_Categories[i].getMerch()[j]);
                        MineDonateNetwork.INSTANCE.sendTo(packet, serverPlayer);
                    }
                }
                
                MineDonateNetwork.INSTANCE.sendTo(new NeedUpdatePacket(1), serverPlayer);

            }
    			
    	}
    	

        return null;
    }
}
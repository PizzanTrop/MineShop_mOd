package ru.log_inil.mc.minedonate.localData.cats;

import ru.log_inil.mc.minedonate.localData.DataOfUiCategoryAbstract;

public class DataOfUiCategoryEntites extends DataOfUiCategoryAbstract {
	
	public DataOfUiCategoryEntites ( ) {
		
		super ( ) ;
		
		categoryButtonText = "Entites" ;
		categoryButtonWidth = 55 ;
		 
	}
	
}

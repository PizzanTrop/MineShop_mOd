package ru.log_inil.mc.minedonate.gui;

public enum DrawType {

	PRE, POST
	
}

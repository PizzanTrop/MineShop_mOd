package ru.log_inil.mc.minedonate.localData.cats;

import ru.log_inil.mc.minedonate.localData.DataOfUiCategoryAbstract;

public class DataOfUiCategoryPrivelegies extends DataOfUiCategoryAbstract {

	public DataOfUiCategoryPrivelegies ( ) {
		
		super ( ) ;

		categoryButtonText = "Privelegies" ;
		categoryButtonWidth = 75 ;

	}
	
}

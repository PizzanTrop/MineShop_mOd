package ru.log_inil.mc.minedonate.localData.cats;

import ru.log_inil.mc.minedonate.localData.DataOfUiCategoryAbstract;

public class DataOfUiCategoryItemsNBlocks extends DataOfUiCategoryAbstract {
	
	public String itemLeft ;
	
	public DataOfUiCategoryItemsNBlocks ( ) {
		
		super ( ) ;

		categoryButtonText = "Items" ;
		categoryButtonWidth = 45 ;
		itemLeft = "Left: " ;
		
	}
	
}

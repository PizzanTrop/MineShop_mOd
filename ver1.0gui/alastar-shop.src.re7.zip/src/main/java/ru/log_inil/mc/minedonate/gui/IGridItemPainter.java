package ru.log_inil.mc.minedonate.gui;

import net.minecraft.client.gui.ScaledResolution;
import ru.alastar.minedonate.gui.ShopGUI;
import ru.alastar.minedonate.merch.IMerch;

public interface IGridItemPainter {

	public void draw ( ShopGUI relative, ScaledResolution sc, int m_Page, int mouseX, int mouseY, float partialTicks, IMerch merch, int gridI, int gridJ ) ;
	
}

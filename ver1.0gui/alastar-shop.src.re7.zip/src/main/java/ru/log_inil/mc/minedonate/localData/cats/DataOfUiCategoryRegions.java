package ru.log_inil.mc.minedonate.localData.cats;

import ru.log_inil.mc.minedonate.localData.DataOfUiCategoryAbstract;

public class DataOfUiCategoryRegions extends DataOfUiCategoryAbstract {

	public DataOfUiCategoryRegions ( ) {
		
		super ( ) ;

		categoryButtonText = "Regions" ;
		categoryButtonWidth = 75 ;
		
	}
	
}

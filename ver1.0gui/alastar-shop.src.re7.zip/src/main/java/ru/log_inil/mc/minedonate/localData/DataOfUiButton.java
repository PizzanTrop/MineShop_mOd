package ru.log_inil.mc.minedonate.localData;

public class DataOfUiButton {

	public String text ;
	public int width ;
	public int height ;
	
	public DataOfUiButton ( ) {
		
		text = "?" ;
		width = 20 ;
		height = 20 ;
		
	}
	
	public DataOfUiButton ( String _text, int _width, int _height ) {
		
		text = _text ;
		width = _width ;
		height = _height ;

	}
	
}
